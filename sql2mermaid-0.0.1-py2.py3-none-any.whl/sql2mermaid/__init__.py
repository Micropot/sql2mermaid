from .sql2mermaid import mermaid_generator, open_sql_file
